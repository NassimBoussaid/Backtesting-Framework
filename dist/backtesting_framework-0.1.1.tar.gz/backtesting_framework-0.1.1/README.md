# Backtesting-Framework

## Overview

The Backtester is a Python module designed to backtest financial trading strategies on historical data. It computes portfolio positions, transaction costs, slippage costs, and returns while allowing for customizable parameters, such as multi-asset support and rebalancing frequency.
